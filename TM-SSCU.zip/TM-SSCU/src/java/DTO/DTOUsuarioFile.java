package DTO;

import java.util.List;
import model.FileMeta;
import model.Usuarios;

public class DTOUsuarioFile {
    private Usuarios user;

    public Usuarios getUser() {
        return user;
    }

    public void setUser(Usuarios user) {
        this.user = user;
    }
}
