function load()
{
	$('#tbl').load('/Busca/buscacli', "id="+$('#id').val());
}
