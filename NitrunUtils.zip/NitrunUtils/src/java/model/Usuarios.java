package model;

import java.io.File;
import java.sql.Blob;

public class Usuarios {
    public int id;
    public String nombre;
    public String correo;
    public String telefono;
    private File documento;
    private Blob documentoBlob;
    
    public Usuarios() {
    }        

    public Usuarios(int id, String nombre, String correo, String telefono, File documento) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.documento = documento;
    }

    public Usuarios(String nombre, String correo, String telefono, File documento) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.documento = documento;
    }

    public Usuarios(int id, String nombre, String correo, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
    }
    
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }    

    public File getDocumento() {
        return documento;
    }

    public void setDocumento(File documento) {
        this.documento = documento;
    }

    public Blob getDocumentoBlob() {
        return documentoBlob;
    }

    public void setDocumento(Blob documentoBlob) {
        this.documentoBlob = documentoBlob;
    }
}